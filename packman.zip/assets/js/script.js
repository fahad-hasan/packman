/**
 * Created by floyd on 28/11/15.
 */


/*
* Initialize all tooltips on DOM-Ready
*/
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();
});
